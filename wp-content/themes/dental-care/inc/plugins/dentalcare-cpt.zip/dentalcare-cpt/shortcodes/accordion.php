<?php

add_action('vc_before_init', 'dental_care_accordion_VC');

function dental_care_accordion_VC() {
    vc_map(array(
        "name" => esc_html__("Accordion", 'dental-care'),
        "base" => "dental_care_accordion",
        "class" => "",
        "category" => esc_html__('Dental Care', 'dental-care'),
        "as_parent" => array('only' => 'dental_care_accordion_item'),
        "show_settings_on_create" => false,
        "js_view" => "VcColumnView",
        "params" => array(
        )
    ));


    vc_map(array(
        "name" => esc_html__("Accordion Item", 'dental-care'),
        "base" => "dental_care_accordion_item",
        "class" => "",
        "category" => esc_html__('Dental Care', 'dental-care'),
        "as_child" => array('only' => 'dental_care_accordion'),
        "show_settings_on_create" => true,
        "params" => array(
            array(
                "type" => "dropdown",
                "holder" => "div",
                "class" => "",
                "heading" => esc_html__("Use Icon", 'dental-care'),
                "param_name" => "icon_en",
                "description" => esc_html__("Choose if to use an icon.", 'dental-care'),
                "value" => array(
                    "" => "",
                    "Yes" => "yes",
                    "No" => "no",
                )
            ),
            array(
                "type" => "icon",
                "holder" => "div",
                "class" => "",
                "param_name" => "icon_select",
                "description" => esc_html__("Choose an icon.", 'dental-care'),
                "dependency" => array("element" => "icon_en", "value" => array("yes")),
            ),
            array(
                "type" => "textfield",
                "holder" => "div",
                "class" => "",
                "heading" => esc_html__("Icon Font Size", 'dental-care'),
                "param_name" => "icon_font_size",
                "description" => esc_html__("Enter icon font size.", 'dental-care'),
            ),
            array(
                "type" => "colorpicker",
                "class" => "",
                "heading" => esc_html__("Icon Color", 'dental-care'),
                "param_name" => "icon_color",
                "description" => esc_html__("Choose icon color", 'dental-care'),
            ),
            array(
                "type" => "colorpicker",
                "class" => "",
                "heading" => esc_html__("Accordion Item Background Color", 'dental-care'),
                "param_name" => "accordion_bgcolor",
                "description" => esc_html__("Choose background color of accordion item.", 'dental-care'),
                "group" => "Design"
            ),
            array(
                "type" => "colorpicker",
                "class" => "",
                "heading" => esc_html__("Accordion Title Text Color", 'dental-care'),
                "param_name" => "accordion_titlecolor",
                "description" => esc_html__("Choose accordion title text color.", 'dental-care'),
                "group" => "Design"
            ),
            array(
                "type" => "colorpicker",
                "class" => "",
                "heading" => esc_html__("Accordion Description Text Color", 'dental-care'),
                "param_name" => "accordion_desccolor",
                "description" => esc_html__("Choose accordion text color.", 'dental-care'),
                "group" => "Design"
            ),
            array(
                "type" => "dropdown",
                "holder" => "div",
                "class" => "",
                "heading" => esc_html__("Enable Shadow", 'dental-care'),
                "param_name" => "accordion_box_shadow_en",
                "description" => esc_html__("Choose to enable/disable box shadow", 'dental-care'),
                "value" => array("" => "", "On" => "on", "Off" => "off"),
                "group" => "Design"
            ),
            array(
                "type" => "textfield",
                "holder" => "div",
                "class" => "",
                "heading" => esc_html__("Title", 'dental-care'),
                "param_name" => "item_title",
                "description" => esc_html__("Enter a title", 'dental-care'),
            ),
            array(
                "type" => "textarea_html",
                "holder" => "div",
                "class" => "",
                "heading" => esc_html__("Description", 'dental-care'),
                "param_name" => "content",
                "description" => esc_html__("Enter a description", 'dental-care'),
            ),
            array(
                "type" => "textfield",
                "holder" => "div",
                "class" => "",
                "heading" => esc_html__("Section ID", 'dental-care'),
                "param_name" => "item_id",
                "description" => esc_html__("Enter a unique id for this item.", 'dental-care'),
            ),
        )
    ));
}

function dental_care_accordion_shortcode($atts, $content) {
    global $post;
    extract(shortcode_atts(array(
        'param' => '',
                    ), $atts));

    $string = '<div class="stronghold-accordion-wrapper">';
    $string .= do_shortcode($content);
    $string .= '</div>';
    return $string;
}

function dental_care_accordion_item_shortcode($atts, $content) {
    global $post;
    extract(shortcode_atts(array(
        'param' => '',
        'icon_en' => '',
        'icon_select' => '',
        'icon_font_size' => '',
        'icon_color' => '',
        'item_title' => '',
        'item_id' => '',
        'accordion_bgcolor' => '',
        'accordion_box_shadow_en' => '',
        'accordion_titlecolor' => '',
        'accordion_desccolor' => '',
                    ), $atts));


    $string = '<div class="accordion-item" style="';

    if ($accordion_bgcolor != '') {
        $string .= 'background: ' . esc_attr($accordion_bgcolor) . ';';
    }

    if ($accordion_box_shadow_en == "on") {
        $string .= ' -webkit-box-shadow: 0 0 10px rgba(0,0,0,0.08);';
        $string .= ' box-shadow: 0 0 10px rgba(0,0,0,0.08);';
    }

    $string .= '">';
    $string .= '<a class="accordion-item-title" href="#' . esc_attr($item_id) . '" data-ll="collapsed" style="';

    if ($accordion_titlecolor != '') {
        $string .= 'color: ' . esc_attr($accordion_titlecolor) . ';';
    }

    $string .= '">';
    if ($icon_select != '' && $icon_en == 'yes'):
        $string .= '<i class="accordion-icon ' . esc_attr($icon_select) . '" style="font-size:' . esc_attr($icon_font_size) . 'px;';

        if ($icon_color != ''):
            $string .= ' color:' . esc_attr($icon_color) . ';';
        endif;

        $string .= '"> </i>';
    endif;

    $string .= '' . esc_html($item_title) . '</a>';
    $string .= '<div id="' . esc_attr($item_id) . '" class="accordion-item-content" style="';

    if ($accordion_bgcolor != '') {
        $string .= 'background: ' . esc_attr($accordion_bgcolor) . ';';
    }

    if ($accordion_desccolor != '') {
        $string .= 'color: ' . esc_attr($accordion_desccolor) . ';';
    }

    $string .= '">';
    $string .= '' . $content . '';
    $string .= '</div>';

    $string .= '</div>';

    return $string;
}

if (class_exists('WPBakeryShortCodesContainer')) {

    class WPBakeryShortCode_dental_care_accordion extends WPBakeryShortCodesContainer {
        
    }

}

if (class_exists('WPBakeryShortCode')) {

    class WPBakeryShortCode_dental_care_accordion_item extends WPBakeryShortCode {
        
    }

}