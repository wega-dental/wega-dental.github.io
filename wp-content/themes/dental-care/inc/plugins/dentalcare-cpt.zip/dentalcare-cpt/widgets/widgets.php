<?php

include_once (DENTALCARE_DIR . '/widgets/widget_opening_hours.php');
include_once (DENTALCARE_DIR . '/widgets/widget_recent_posts.php');
include_once (DENTALCARE_DIR . '/widgets/widget_social.php');
include_once (DENTALCARE_DIR . '/widgets/widget_company_info.php');
include_once (DENTALCARE_DIR . '/widgets/widget_testimonials.php');
